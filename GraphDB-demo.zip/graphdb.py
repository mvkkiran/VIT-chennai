from langchain_community.graphs import OntotextGraphDBGraph
import os

from langchain.chains import OntotextGraphDBQAChain
from langchain_openai import ChatOpenAI
from cred import *
# feeding the schema using a user construct query

os.environ["GRAPHDB_USERNAME"] = "demo"
os.environ["GRAPHDB_PASSWORD"] = "demo"
graph = OntotextGraphDBGraph(
    query_endpoint="http://localhost:7200/repositories/starwars-rdf",
    local_file="data.ttl" # change the path here
)

# Set the environment variable `OPENAI_API_KEY` to your OpenAI API key
# os.environ["OPENAI_API_KEY"] = "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"



chain = OntotextGraphDBQAChain.from_llm(
    ChatOpenAI(openai_api_key=openai_key,temperature=0, model_name=model),
    graph=graph,
    verbose=True,
)

print(chain.invoke({chain.input_key: "List the planets which has terrain with mountains?"})[chain.output_key])