from langchain.chains import GraphSparqlQAChain
from langchain_community.graphs import RdfGraph
from langchain.prompts.prompt import PromptTemplate
from langchain_openai import ChatOpenAI
from cred import *
import os
graph = RdfGraph(
    # source_file="http://www.w3.org/People/Berners-Lee/card",
    # source_file = "https://boshontology.000webhostapp.com/SmartHomeBuildingOntology.owl",
    source_file="bosh.ttl",
    # standard="owl",
    local_copy="test.owl",
)
SPARQL_GENERATION_TEMPLATE = """
  Write a SPARQL SELECT query for querying a graph database.
  The ontology schema delimited by triple backticks in Turtle format is:
  ```
  {schema}
  ```
  Use only the classes and properties provided in the schema to construct the SPARQL query.
  Do not use any classes or properties that are not explicitly provided in the SPARQL query.
  Include all necessary prefixes.
  Do not include any explanations or apologies in your responses.
  Do not wrap the query in backticks in chain.
  Do not include any text except the SPARQL query generated.
  The question delimited by triple backticks is:
  ```
  {prompt}
  ```
  """
SPARQL_GENERATION_PROMPT = PromptTemplate(
      input_variables=["schema", "prompt"],
      template=SPARQL_GENERATION_TEMPLATE
  )
graph.load_schema()
schema = graph.get_schema
print(graph.get_schema)

# chain = GraphSparqlQAChain.from_llm(
#     ChatOpenAI(temperature=0), graph=graph, verbose=True, sparql_prompt=SPARQL_GENERATION_PROMPT
# )
#
# print(chain.invoke({chain.input_key: "What is a american pizza?"})[chain.output_key])
# Create the chain
chain = GraphSparqlQAChain.from_llm(
    ChatOpenAI(temperature=0, openai_api_key=openai_key, model=model), graph=graph, verbose=True, sparql_prompt=SPARQL_GENERATION_PROMPT
)

# Input variables for the chain
input_variables = {"schema": schema, chain.input_key: "give the list of sensing devices"}

# Generate the output from the chain
output = chain.invoke(input_variables)

# Print the generated SPARQL query
generated_sparql = output["generated_query"]
print("Generated SPARQL query:")
print(generated_sparql)

# Invoke the SPARQL query
sparql_result = chain.invoke({"generated_query": generated_sparql})

# Further processing of the SPARQL result...
