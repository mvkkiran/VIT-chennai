from langchain_openai import ChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain.chains import LLMChain
from langchain.chains.conversation.memory import ConversationBufferMemory
from cred import *

chat_llm = ChatOpenAI(openai_api_key=openai_key, model=model)

prompt = PromptTemplate(
    template="""You are a surfer dude, having a conversation about the surf conditions on the beach.
Respond using surfer slang.

Chat History: {chat_history}
Context: {context}
Question: {question}
""",
    input_variables=["chat_history","context", "question"],
)
# As each call to the LLM is stateless, you need to include the chat history in every call to the LLM.

memory = ConversationBufferMemory(memory_key="chat_history", input_key="question", return_messages=True)

# add verbose=True to see the conversation history in the console.
chat_chain = LLMChain(llm=chat_llm, prompt=prompt, memory=memory)

current_weather = """
    {
        "surf": [
            {"beach": "Fistral", "conditions": "6ft waves and offshore winds"},
            {"beach": "Polzeath", "conditions": "Flat and calm"},
            {"beach": "Watergate Bay", "conditions": "3ft waves and onshore winds"}
        ]
    }"""

response = chat_chain.invoke({
    "context": current_weather,
    "question": "Hi, I am at Watergate Bay. What is the surf like?"
})
print(response["text"])

response = chat_chain.invoke({
    "context": current_weather,
    "question": "Where I am?"
})
print(response["text"])


# running a loop
while True:
    question = input("> ")
    response = chat_chain.invoke({
        "context": current_weather,
        "question": question
        })

    print(response["text"])