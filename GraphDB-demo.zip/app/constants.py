TITLE = f"""
<style>
   @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');
</style>

<div style='text-align: center;'>
    <div style='font-size: 1.5rem; font-weight: 600; font-family: "Roboto"; color: #BE2BBB;'>Safety BOT</div>
    <div style='font-size: 0.8rem; font-weight: 600; font-family: "Roboto"; color: #595454;'>WWPS Knowledge Assistant</div>
</div>

"""