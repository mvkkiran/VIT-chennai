from constants import TITLE
import streamlit as st
import streamlit.components.v1 as components

def sidebar():
    with st.sidebar:
        # st.markdown(TITLE,unsafe_allow_html=True)
        st.markdown("""Questions you can ask of the dataset:""", unsafe_allow_html=True)
        st.markdown("""""", unsafe_allow_html=True)
        st.markdown("""
                    <style>
                        div[data-testid="column"] {
                            width: fit-content !important;
                            flex: unset;
                        }
                        div[data-testid="column"] * {
                            width: fit-content !important;
                        }
                    </style>
                    """, unsafe_allow_html=True)


        sample_questions = "List 2 cases along with case attributes case id, country, AER number, Death case. Format the output in Tabular format.","Get the case with maximum number of events. output the case id and count in tabular format.","List 2 cases with their corresponding case narrative, that has death case as Yes. Output the case id, narrative and death case."

        for text, col in zip(sample_questions, st.columns(len(sample_questions))):
            if col.button(text, key=text):
                st.session_state["sample"] = text