from langchain.agents import AgentExecutor, create_react_agent
from langchain import hub
from langchain_community.graphs import OntotextGraphDBGraph
from llm import llm #call llm from llm.py
from langchain.tools import Tool
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
from langchain.prompts import PromptTemplate
from langchain.chains import OntotextGraphDBQAChain
import os

os.environ["GRAPHDB_USERNAME"] = "demo"
os.environ["GRAPHDB_PASSWORD"] = "demo"
graph = OntotextGraphDBGraph(
    query_endpoint="http://localhost:7200/repositories/starwars-rdf",
    local_file="../data.ttl" # change the path here
)

GRAPHDB_SPARQL_FIX_TEMPLATE = """
This following SPARQL query delimited by triple backticks
```
{generated_sparql}
```
is not valid.
The error delimited by triple backticks is
``` 
{error_message}
```
Give me a correct version of the SPARQL query.
Do not change the logic of the query.
Do not include any explanations or apologies in your responses.
Do not wrap the query in backticks.
Do not include any text except the SPARQL query generated.
Limit the results by adding 'limit 10' at the end of the sparql query.
The ontology schema delimited by triple backticks in Turtle format is:
```
{schema}
```
"""

GRAPHDB_SPARQL_FIX_PROMPT = PromptTemplate(
    input_variables=["error_message", "generated_sparql", "schema"],
    template=GRAPHDB_SPARQL_FIX_TEMPLATE,
)


graph_chain = OntotextGraphDBQAChain.from_llm(
    llm=llm, graph=graph, verbose=True, sparql_prompt=GRAPHDB_SPARQL_FIX_PROMPT,
    return_sparql_query=True
)

tools =[
    Tool.from_function(
        name = "General Chat",
        description="For general chat not covered by other tools",
        func=llm.invoke,
        return_direct=False
    ),
    Tool.from_function(
        name="Graph Search",
        description="Use when needing to find information related to star wars. ",
        func= graph_chain.run,
        return_direct=False
    )
]

#to keep the history of messages
memory = ConversationBufferWindowMemory(
    memory_key='chat_history',
    k=2,
    return_messages=True,
)


#defining the scope of the AGENT
prompt = """
You are a Movie expert providing information about Movies and specially about the Star Wars series.
Be as helpful as possible and return as much information as possible.
Do not answer any questions that do not relate to patient safety, adverse events and its details.
Do not answer any questions using your pre-trained knowledge, only use the information provided in the context.

TOOLS:
------

You have access to the following tools:

{tools}

To use a tool, please use the following format:

```
Thought: Do I need to use a tool? Yes
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action

```

When you have a response to say to the Human, or if you do not need to use a tool, you MUST use the format:

```
Thought: Do I need to use a tool? No
Final Answer: [your response here]
```

Begin!

Previous conversation history:
{chat_history}

New input: {input}
{agent_scratchpad}
"""
agent_prompt = PromptTemplate.from_template(prompt)

agent = create_react_agent(llm,tools,agent_prompt)
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    memory=memory,
    verbose=True
)

def generate_response(prompt):
    response = agent_executor.invoke({"input": prompt})
    print("Response:", response)
    return response
