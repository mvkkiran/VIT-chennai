import streamlit as st
from langchain.chains import OntotextGraphDBQAChain
from langchain_community.graphs import OntotextGraphDBGraph# Replace with the correct import based on your library
from cred import *
from langchain_openai import ChatOpenAI
import os
# Initialize your GraphDB QA Chain
# Replace with actual configuration details
os.environ["GRAPHDB_USERNAME"] = "demo"
os.environ["GRAPHDB_PASSWORD"] = "demo"

graph = OntotextGraphDBGraph(
    query_endpoint="http://localhost:7200/repositories/starwars-rdf",
    local_file="data.ttl" # change the path here
)


chain = OntotextGraphDBQAChain.from_llm(
    ChatOpenAI(openai_api_key=openai_key,temperature=0, model_name=model),
    graph=graph,
    verbose=True,
)

# Streamlit app interface
st.title('GraphDB with Streamlit')

st.write("Ask a question about the data in your GraphDB instance:")

user_question = st.text_input("Your question:")

if st.button('Submit'):
    if user_question:
        try:
            # Query the QA Chain with the user question
            answer = chain.invoke(user_question)
            st.write("Answer:", answer)
        except Exception as e:
            st.error(f"An error occurred: {e}")
    else:
        st.warning("Please enter a question.")
